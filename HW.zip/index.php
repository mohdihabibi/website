<?php
$title = "home";
include 'template.php';
?>